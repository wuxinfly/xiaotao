# XiaoTao

小涛（XiaoTao）是一个面向软件协作的 Agent Skill。你只需要告诉小涛目标；它按需要组织分析、实现、验证和交接。

## 最快开始

在你的项目目录运行（需要 Node.js 20.19+、Python 和 PowerShell）：

```bash
npx @wxfly/xiaotao@latest init
```

它会检测本机环境并让你选择要安装的宿主：

```text
1. DSH
2. Codex / 通用 Agent Skills
3. Claude Code
4. Antigravity
```

选完会自动安装和自检。实际 Skill 装在用户级目录；当前项目只会生成：

```text
.xiaotao/installation.json
```

这个文件记录本项目启用了哪些宿主，`.xiaotao/` 默认不提交 Git。

## 从源码运行（开发者）

先进入仓库的 `xt-skills/` 目录，再运行：

```bash
npm run xiaotao:init
```

## 常用命令

```bash
# 第一次安装：选择宿主并安装
npx @wxfly/xiaotao@latest init

# 更新当前项目已选择的宿主
npx @wxfly/xiaotao@latest update

# 检查安装是否正常，不修改任何文件
npx @wxfly/xiaotao@latest doctor

# 安装 Codex Skill 与增强插件
npx @wxfly/xiaotao@latest codex
```

`update` 会更新电脑上共享的 XiaoTao 安装。如果当前仓库版本比已安装版本新，会先提示你确认。`doctor` 会检查 Skill 文件、管理标记，以及 DSH 插件是否已激活。

`codex` 会安装通用 Codex Skill、准备独立 marketplace，并在本机找到 Codex CLI 时执行 `codex plugin add xiaotao-codex@xiaotao`。如果 CLI 不可用，可加 `--prepare` 只准备来源，再到桌面端 Plugins 中安装。安装或启用插件不会自动信任 Hooks，首次使用前仍需在 Codex 中审查。

当前本地验证阶段，`init` 必须在交互式终端中运行，不提供 `--tools` 或 CI 批量初始化参数。`--json` 支持 `doctor` 和 `codex`。

## 安装位置

| 选择 | 安装位置 |
| --- | --- |
| Codex / 通用 Agent Skills | `~/.agents/skills/xiaotao/` |
| Claude Code | `~/.claude/skills/xiaotao/` |
| Antigravity | `~/.gemini/config/plugins/xiaotao-antigravity/`（含 PreInvocation 恢复 Hook） |
| DSH | `~/.dsh/profiles/web/` 的插件配置 |

多个项目可以各自运行一次 `init`。每个项目都有自己的 `.xiaotao/installation.json`，但所有项目共用同一份用户级 XiaoTao；不会反复复制多份 Skill。

如果用户级目标目录已有不是 XiaoTao 管理的内容，初始化会停止保护它。确认需要接管时可运行：

```bash
npx @wxfly/xiaotao@latest init --force
```

## 旧项目升级

早期版本会把 Skill 复制到项目内目录，并使用 schema v1 的 `.xiaotao/installation.json`。新版本不会自动删除或迁移这些文件。

在旧项目目录执行一次 `npx @wxfly/xiaotao@latest init`，重新选择宿主即可写入新的项目记录并安装用户级 Skill；旧项目内副本请在确认新安装可用后自行归档或删除。

## 在宿主中使用

安装后，在项目里直接说：

```text
小涛，帮我评审这个方案，只说主要风险和建议。
小涛，先调查这个问题，不要改代码。
小涛，按刚才确定的方案开始修改。
```

小涛不会自动扩权或静默开启固定流程；需要持久化任务、记忆或 Playbook 时，会按 Skill 的规则处理。

## 自动积累改进建议

阶段收尾、用户纠正或同类做法反复失败时，小涛会检查自身规则、工具和协作有没有不顺畅的地方。有证据才记录在项目本地 `.xiaotao/evolution/`，同类问题合并、独立观察累计；没有问题不凑建议，用户要求不保存时跳过。记录包含问题、影响、脱敏证据、改进建议和验收方法，作为待验证的产品反馈。

需要交给维护小涛的 AI 时直接说：

```text
整理小涛的改进建议，给我一份交接清单。
```

小涛生成 `.xiaotao/evolution/exports/handoff.md`，由你手动交给维护 GitHub 源码的设计 AI。建议不会自动修改已安装技能、自动提交或发布。可以记录处理结论，已修复或拒绝的问题出现新证据时重新待处理。该机制依靠 Agent 按 Core 规范复盘，没有后台定时任务；真实宿主遵循情况需单独验收。使用和限制见 [自身改进说明](xiaotao/references/evolution.md)。

## 开发与验证

需要 Node.js 20.19 或更高版本。

```bash
npm test
npm run test:contracts
```

DSH Adapter、Codex Desktop 插件和 Skill 内部协议的详细说明在 [`adapters/`](adapters/) 与 [`docs/`](../docs/) 下。CLI 只负责安装、更新和诊断，绝不调度 Worker 或直接运行工作流。

### ZCode

`xiaotao init` 可选择 ZCode，准备本地插件市场；随后需在 ZCode 客户端安装启用。
支持 Core、共享项目记忆、一层原生 Worker 和每轮结束前的进度检查提醒。
安装、更新步骤与尚未验收的限制见 [ZCode 适配说明](adapters/zcode/README.md)。
