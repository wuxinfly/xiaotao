import { cp, mkdir, readFile, readdir, stat, writeFile } from 'node:fs/promises';
import { execFile } from 'node:child_process';
import path from 'node:path';
import { promisify } from 'node:util';

import { resolveUserHome, SCENES } from './scenes.js';
import { installCliMarketplace } from '../adapters/codex/install-local.mjs';

const execFileAsync = promisify(execFile);
const CONFIG_PATH = '.xiaotao/installation.json';
const GLOBAL_CONFIG = '.xiaotao/managed-installation.json';
const MARKER_NAME = '.xiaotao-managed.json';
const MANAGED_PACKAGE = '@wxfly/xiaotao';
const LEGACY_MANAGED_PACKAGE = 'xiaotao-ai-workflow';

async function pathExists(target) {
  try { await stat(target); return true; } catch (error) { if (error.code === 'ENOENT') return false; throw error; }
}
async function readJson(target) {
  return JSON.parse((await readFile(target, 'utf8')).replace(/^\uFEFF/, ''));
}
async function isNonEmpty(target) {
  try { const value = await stat(target); return !value.isDirectory() || (await readdir(target)).length > 0; }
  catch (error) { if (error.code === 'ENOENT') return false; throw error; }
}
async function isManaged(target) {
  try {
    const managed = await readJson(path.join(target, MARKER_NAME));
    if (managed.package === MANAGED_PACKAGE || managed.package === LEGACY_MANAGED_PACKAGE) return true;
  } catch (error) {
    if (error.code !== 'ENOENT' && !(error instanceof SyntaxError)) throw error;
  }
  try {
    const source = await readJson(path.join(target, '.xiaotao-source.json'));
    if (source.owner && source.owner.startsWith('xiaotao-ai-workflow')) return true;
  } catch (error) {
    if (error.code !== 'ENOENT' && !(error instanceof SyntaxError)) throw error;
  }
  return false;
}
async function packageInfo(packageRoot) {
  const manifest = await readJson(path.join(packageRoot, 'package.json'));
  const skillSource = path.join(packageRoot, 'xiaotao');
  if (manifest.name !== MANAGED_PACKAGE || typeof manifest.version !== 'string' || !(await pathExists(path.join(skillSource, 'SKILL.md')))) {
    throw new Error(`Invalid XiaoTao package at ${packageRoot}`);
  }
  return { version: manifest.version, skillSource };
}
function projectConfig(projectRoot) { return path.join(path.resolve(projectRoot), CONFIG_PATH); }
function globalConfig(environment) { return path.join(resolveUserHome(environment), GLOBAL_CONFIG); }

export async function readInstallation(projectRoot) { return readJson(projectConfig(projectRoot)); }
export async function requireCurrentInstallation(projectRoot) {
  const metadata = await readInstallation(projectRoot);
  if (metadata.schema_version !== 2 || !Array.isArray(metadata.scenes) || !metadata.targets) {
    throw new Error('This project uses old XiaoTao installation metadata. Run xiaotao init again. Existing project-local Skill files are left unchanged.');
  }
  return metadata;
}
export async function readGlobalInstallation(environment = process.env) {
  try { return await readJson(globalConfig(environment)); } catch (error) { if (error.code === 'ENOENT') return null; throw error; }
}
export async function globalUpdateNotice({ packageRoot, environment = process.env }) {
  const current = await packageInfo(path.resolve(packageRoot));
  const previous = await readGlobalInstallation(environment);
  return previous?.package_version && previous.package_version !== current.version
    ? { from: previous.package_version, to: current.version } : null;
}

export async function installDsh({ packageRoot, target, environment, command = execFileAsync }) {
  const script = path.join(packageRoot, 'adapters', 'deepseek-harness', 'scripts', 'install-local.mjs');
  if (!(await pathExists(script))) throw new Error('DSH adapter installer is missing from this checkout');
  await command(process.execPath, [script, '--profile', target.profile, '--dsh-home', target.dsh_home], {
    cwd: packageRoot, env: { ...environment, DSH_HOME: target.dsh_home }, windowsHide: true,
  });
}
export async function verifyDsh(target, environment, command = execFileAsync) {
  try {
    const { stdout, stderr } = await command('dsh', ['--profile', target.profile, '--dump-config'], {
      cwd: path.join(target.dsh_home, 'profiles', target.profile), env: { ...environment, DSH_HOME: target.dsh_home }, windowsHide: true,
    });
    const ok = `${stdout}\n${stderr}`.includes('@xiaotao-ai/dsh-adapter') || `${stdout}\n${stderr}`.includes('xiaotao-adapter');
    return { ok, message: ok ? undefined : 'DSH config does not contain the XiaoTao adapter.' };
  } catch (error) {
    return { ok: false, message: error.code === 'ENOENT' ? 'dsh command was not found on PATH.' : `Could not inspect DSH: ${error.message}` };
  }
}

export async function installAntigravity({ packageRoot, target, skillSource, version }) {
  const adapterSource = path.join(packageRoot, 'adapters', 'antigravity', 'xiaotao-antigravity');
  await mkdir(target.path, { recursive: true });
  await cp(adapterSource, target.path, { recursive: true, force: true });
  const pluginSkillDir = path.join(target.path, 'skills', 'xiaotao');
  await mkdir(pluginSkillDir, { recursive: true });
  await cp(skillSource, pluginSkillDir, { recursive: true, force: true });
  await writeFile(path.join(target.path, MARKER_NAME), `${JSON.stringify({ package: MANAGED_PACKAGE, scene: 'antigravity', version }, null, 2)}\n`);
}

export async function installZcode({ packageRoot, target, skillSource, version }) {
  const plugin = path.join(target.path, 'plugins', 'xiaotao-zcode');
  await mkdir(plugin, { recursive: true });
  await cp(path.join(packageRoot, 'adapters', 'zcode', 'plugin'), plugin, { recursive: true, force: true });
  await cp(skillSource, path.join(plugin, 'skills', 'xiaotao'), { recursive: true, force: true });
  const manifestPath = path.join(plugin, '.zcode-plugin', 'plugin.json');
  const manifest = await readJson(manifestPath);
  await writeFile(manifestPath, JSON.stringify({ ...manifest, version }, null, 2) + '\n');
  await writeFile(path.join(target.path, 'marketplace.json'), JSON.stringify({ name: 'xiaotao-local', plugins: [{ name: 'xiaotao-zcode', source: './plugins/xiaotao-zcode', version }] }, null, 2) + '\n');
  await writeFile(path.join(target.path, MARKER_NAME), JSON.stringify({ package: MANAGED_PACKAGE, scene: 'zcode', version }) + '\n');
}

export async function installCodex({ projectRoot, packageRoot, environment = process.env, prepare = false, command = execFileAsync }) {
  const resolvedPackage = path.resolve(packageRoot);
  const { version, skillSource } = await packageInfo(resolvedPackage);
  const skillsTarget = SCENES.skills.resolveTarget(environment);
  if ((await isNonEmpty(skillsTarget.path)) && !(await isManaged(skillsTarget.path))) {
    throw new Error(`Destination is not managed by XiaoTao: ${skillsTarget.path}. Run xiaotao init with --force to adopt it.`);
  }
  await mkdir(skillsTarget.path, { recursive: true });
  await cp(skillSource, skillsTarget.path, { recursive: true, force: true });
  await writeFile(path.join(skillsTarget.path, MARKER_NAME), `${JSON.stringify({ package: MANAGED_PACKAGE, scene: 'skills', version }, null, 2)}\n`);

  const now = new Date().toISOString();
  let previous = null;
  try { previous = await readInstallation(projectRoot); } catch (error) { if (error.code !== 'ENOENT') throw error; }
  const scenes = [...new Set([...(previous?.scenes ?? []), 'skills'])];
  const targets = { ...(previous?.targets ?? {}), skills: skillsTarget };
  const metadata = { schema_version: 2, package: MANAGED_PACKAGE, package_version: version, scenes, targets, installed_at: previous?.installed_at ?? now, updated_at: now };
  await mkdir(path.dirname(projectConfig(projectRoot)), { recursive: true });
  await writeFile(projectConfig(projectRoot), `${JSON.stringify(metadata, null, 2)}\n`);
  const previousGlobal = await readGlobalInstallation(environment);
  const globalScenes = [...new Set([...(previousGlobal?.scenes ?? []), ...scenes])];
  const global = { schema_version: 1, package: MANAGED_PACKAGE, package_version: version, scenes: globalScenes, targets: { ...(previousGlobal?.targets ?? {}), ...targets }, updated_at: now };
  await mkdir(path.dirname(globalConfig(environment)), { recursive: true });
  await writeFile(globalConfig(environment), `${JSON.stringify(global, null, 2)}\n`);

  const marketplace = await installCliMarketplace({ homeDir: resolveUserHome(environment) });
  const checks = (await doctorInstallation(projectRoot, environment, command)).checks;
  let installed = false;
  let pluginId = 'xiaotao-codex@xiaotao';
  let installError;
  if (!prepare) {
    try {
      await command('codex', ['plugin', 'marketplace', 'add', marketplace.root, '--json'], { cwd: resolvedPackage, env: environment, windowsHide: true });
      const output = await command('codex', ['plugin', 'add', pluginId, '--json'], { cwd: resolvedPackage, env: environment, windowsHide: true });
      installed = true;
      if (output.stdout) {
        try { pluginId = JSON.parse(output.stdout).pluginId ?? pluginId; } catch {}
      }
    } catch (error) {
      installError = error.code === 'ENOENT' ? '未找到 codex CLI；已准备来源，请在 Codex 桌面端安装。' : `Codex CLI 安装失败：${error.message}`;
    }
  }
  return {
    ok: checks.every((check) => check.ok) && (prepare || installed), installed, pluginId, version, marketplace: marketplace.marketplace,
    marketplaceRoot: marketplace.root, installError, checks,
  };
}

export async function installScenes({ projectRoot, packageRoot, sceneIds, force = false, environment = process.env, command = execFileAsync }) {
  const resolvedPackage = path.resolve(packageRoot);
  const { version, skillSource } = await packageInfo(resolvedPackage);
  const scenes = [...new Set(sceneIds)];
  for (const id of scenes) if (!SCENES[id]) throw new Error(`Unknown installation target: ${id}`);
  const targets = Object.fromEntries(scenes.map((id) => [id, SCENES[id].resolveTarget(environment)]));

  for (const id of scenes.filter((scene) => scene !== 'dsh')) {
    const target = targets[id].path;
    if ((await isNonEmpty(target)) && !(await isManaged(target)) && !force) {
      throw new Error(`Destination is not managed by XiaoTao: ${target}. Re-run init with --force to adopt it.`);
    }
  }
  for (const id of scenes) {
    const target = targets[id];
    if (id === 'dsh') { await installDsh({ packageRoot: resolvedPackage, target, environment, command }); continue; }
    if (id === 'zcode') { await installZcode({ packageRoot: resolvedPackage, target, skillSource, version }); continue; }
    if (id === 'antigravity') {
      await installAntigravity({ packageRoot: resolvedPackage, target, skillSource, version });
      continue;
    }
    await mkdir(target.path, { recursive: true });
    await cp(skillSource, target.path, { recursive: true, force: true });
    await writeFile(path.join(target.path, MARKER_NAME), `${JSON.stringify({ package: MANAGED_PACKAGE, scene: id, version }, null, 2)}\n`);
  }

  const now = new Date().toISOString();
  let previous = null;
  try { previous = await readInstallation(projectRoot); } catch (error) { if (error.code !== 'ENOENT') throw error; }
  const metadata = { schema_version: 2, package: MANAGED_PACKAGE, package_version: version, scenes, targets, installed_at: previous?.installed_at ?? now, updated_at: now };
  await mkdir(path.dirname(projectConfig(projectRoot)), { recursive: true });
  await writeFile(projectConfig(projectRoot), `${JSON.stringify(metadata, null, 2)}\n`);
  if (scenes.length > 0) {
    const previousGlobal = await readGlobalInstallation(environment);
    const globalScenes = [...new Set([...(previousGlobal?.scenes ?? []), ...scenes])];
    const global = { schema_version: 1, package: MANAGED_PACKAGE, package_version: version, scenes: globalScenes, targets: { ...(previousGlobal?.targets ?? {}), ...targets }, updated_at: now };
    await mkdir(path.dirname(globalConfig(environment)), { recursive: true });
    await writeFile(globalConfig(environment), `${JSON.stringify(global, null, 2)}\n`);
  }
  return { ...metadata, checks: (await doctorInstallation(projectRoot, environment, command)).checks };
}

export async function updateScenes({ projectRoot, packageRoot, environment = process.env, command = execFileAsync }) {
  const metadata = await requireCurrentInstallation(projectRoot);
  return installScenes({ projectRoot, packageRoot, sceneIds: metadata.scenes, environment, command });
}

export async function doctorInstallation(projectRoot, environment = process.env, command = execFileAsync) {
  const checks = [];
  let metadata;
  try { metadata = await readInstallation(projectRoot); checks.push({ code: 'config_present', ok: true, path: CONFIG_PATH }); }
  catch (error) { return { ok: false, checks: [{ code: 'config_missing', ok: false, path: CONFIG_PATH, message: error.code === 'ENOENT' ? 'Run xiaotao init first.' : error.message }] }; }
  if (metadata.schema_version !== 2 || !Array.isArray(metadata.scenes) || !metadata.targets) return { ok: false, checks: [...checks, { code: 'config_invalid', ok: false, message: 'Old installation metadata. Run xiaotao init again; existing project-local Skill files are left unchanged.' }] };
  for (const id of metadata.scenes) {
    const target = metadata.targets[id];
    if (!SCENES[id] || !target) { checks.push({ code: 'scene_unknown', ok: false, scene: id }); continue; }
    if (id === 'dsh') { const result = await verifyDsh(target, environment, command); checks.push({ code: result.ok ? 'dsh_active' : 'dsh_inactive', ...result, scene: id }); continue; }
    if (id === 'zcode') {
      for (const relative of ['marketplace.json', 'plugins/xiaotao-zcode/.zcode-plugin/plugin.json', 'plugins/xiaotao-zcode/hooks/hooks.json', 'plugins/xiaotao-zcode/hooks/context.mjs', 'plugins/xiaotao-zcode/skills/xiaotao/SKILL.md', MARKER_NAME]) {
        const file = path.join(target.path, relative);
        let ok = false;
        try { const text = await readFile(file, 'utf8'); if (relative.endsWith('.json')) JSON.parse(text); ok = true; } catch {}
        checks.push({ code: ok ? 'zcode_file_present' : 'zcode_file_invalid', ok, scene: id, path: file });
      }
      checks.push({ code: 'zcode_activation_unverified', ok: true, scene: id, message: `插件文件已准备；请在 ZCode 设置 → 插件 → 添加插件市场中加入 ${target.path} 并安装启用 xiaotao-zcode。更新后刷新市场、更新插件并新建会话。这里只检查文件，不证明客户端已启用。` });
      continue;
    }
    if (id === 'antigravity') {
      const pluginManifest = path.join(target.path, 'plugin.json');
      const hooksJson = path.join(target.path, 'hooks.json');
      const skill = path.join(target.path, 'skills', 'xiaotao', 'SKILL.md');
      const pluginOk = (await pathExists(pluginManifest)) && (await pathExists(hooksJson));
      const skillOk = await pathExists(skill);
      const markerOk = await isManaged(target.path);
      checks.push({ code: pluginOk ? 'plugin_present' : 'plugin_missing', ok: pluginOk, scene: id, path: target.path });
      checks.push({ code: skillOk ? 'skill_present' : 'skill_missing', ok: skillOk, scene: id, path: skill });
      checks.push({ code: markerOk ? 'marker_present' : 'marker_missing', ok: markerOk, scene: id, path: path.join(target.path, MARKER_NAME) });
      continue;
    }
    const skill = path.join(target.path, 'SKILL.md');
    const skillOk = await pathExists(skill); const markerOk = await isManaged(target.path);
    checks.push({ code: skillOk ? 'skill_present' : 'skill_missing', ok: skillOk, scene: id, path: skill });
    checks.push({ code: markerOk ? 'marker_present' : 'marker_missing', ok: markerOk, scene: id, path: path.join(target.path, MARKER_NAME) });
  }
  return { ok: checks.every((check) => check.ok), checks };
}
