# Result

Validator fixture result.
