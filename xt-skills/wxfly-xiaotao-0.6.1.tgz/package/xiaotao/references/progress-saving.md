# 阶段进度：一次保存

在阶段结束交付前合并保存一次，连续修改和验证不分开写；长任务在重要决策、阻塞或即将中断时补存。无新事实或用户明确不保存时跳过。普通讨论与轻任务不因保存创建 Temporary/Task。

同一会话不重复读取未变化的规范。正常成功不播报内部步骤；失败简短说明哪部分已保存，不反复换 shell 或手工构造锁、快照、事务。

保存本阶段事实后，顺带检查小涛自身是否有可复用的协作摩擦；有证据时才按 [evolution.md](evolution.md) 记录独立的产品建议。没有问题不创建记录，不重复计数同一观察，不将建议当作已批准规则；建议保存失败不阻塞业务交付。用户要求不保存时，两条路径都跳过。

## 通用入口

调用可信安装的 Core 脚本，以 stdin 提交 JSON：

```text
python <core>/scripts/save_progress.py --project-root <project>
```

```json
{
  "request_id": "session-stage-unique-id",
  "topic_id": "activity-fix",
  "title": "活动修复",
  "summary": "修正活动白名单校验",
  "details": "补充实现依据与需要保留的细节。",
  "validation": "相关测试通过；尚未部署。",
  "next_steps": "等待验收。"
}
```

- 默认独立记录：`topic_id` 为稳定小写主题 ID；同日后续进度沿用它。`title`、`summary` 必填，其他事实字段可省略。
- `request_id` 每个不同阶段唯一；结果不确定或部分失败时重试原 JSON，不换 ID。脚本固定首次请求的日期、时区与待提交版本，跨午夜重试仍回到原日期。
- 有明确关联工作时添加 `work_path`，仅限已有 Task `progress.md` 或 Temporary `current.md`。脚本保留原文，追加本阶段进度，内部检查版本/hash、加锁并原子写入和回读；不修改任务生命周期或创建任务。当天只保留汇总、验证、下一步和工作链接，详细说明留在工作记录。
- 无关联工作时仅写当天详情；同日更新保留旧事实并追加新进展，完全相同的内容不制造新 revision。详情达到容量上限时明确失败，由用户决定整理或拆分，不截断历史。
- 返回 `status`、`path`、`revision`、`work_status`、`daily_status` 和 `navigation_status`。`saved`/`duplicate`/`unchanged` 表示每日事实可回读；导航 `pending` 不代表事实丢失。`failed` 时看各阶段状态，已提交部分不会回滚。
- 恢复记录在 `.xiaotao/runtime/progress-saves/`；它包含日期、请求摘要及必要的工作前后快照，属于本地记忆数据，不自动共享。不要在请求未解决前删除恢复记录。重试遇到更新版本会停止，不覆盖较新进度。
- 常规导航只读当天详情与相邻层的有界摘要，更新当天、月、年和根入口。升级缺少摘要元数据的旧导航时自动完整重建一次。手工正文仍受保护；需要明确修复历史导航时才用 `timeline_catalog.py build`。底层每日协议见 [daily-memory.md](daily-memory.md)，不是日常收尾的必读清单。

## 同模块小修归并

对齐、文案、间距、颜色等连续小修，使用 `record_type: "minor"`，明确传入稳定的 `project_id`、`module_id`、`group_id`，不要每修一个问题就换分组。三个 ID 均为 1–64 位小写字母、数字、连字符或下划线，首位为字母或数字。UI 和调度逻辑等不同类别使用不同分组。

```json
{
  "request_id": "session-switch-align",
  "record_type": "minor",
  "project_id": "app-center",
  "module_id": "scheduled-tasks",
  "group_id": "ui-fixes",
  "title": "开关顶部对齐",
  "summary": "修正长标题下开关的对齐。",
  "validation": "长短标题下均显示正常。"
}
```

小修无需 `topic_id`；脚本按日期和上述三个 ID 定位同一份 detail，文件名为 `minor-<分组摘要>.md`，不根据标题或文件名前缀猜模块。分组标题固定，每次正文按本地时间、修改标题追加；导航摘要显示最新进展，历史事实保留在正文。不同日期自动分开；重要排查、架构变更、阶段完成使用独立记录（省略 `record_type` 或填 `standalone`），不传分组字段。`minor-` 为保留的 topic 前缀。

并发写同分组会返回 busy，保留原 JSON 重试；重复请求不重复追加。分组必须保持同一 `work_path` 关联；不同任务需要不同分组。单份详情仍受 6000 字符和 32 KiB 限制，达到上限会明确失败并保留原文，不自动截断或拆文件；需要整理或明确启用新的分组。已有历史碎片不自动合并，不手改生成的 detail、summary。

## Codex：保存与回执一次完成

优先调用可信插件脚本 `progress-check.mjs --save`，不用分别运行 Python 和 `--ack saved`：

```json
{
  "cwd": "<project>",
  "session_id": "<Hook 提供的 session_id>",
  "turn_id": "<Hook 提供的 turn_id>",
  "progress": {
    "topic_id": "activity-fix",
    "title": "活动修复",
    "summary": "修正活动白名单校验",
    "validation": "相关测试通过"
  }
}
```

一次阶段收尾可省略 `request_id`，插件从 Session/Turn 生成稳定 ID；同轮多个阶段补存时显式提供不同 ID。插件只执行用户安装的 Core（默认用户级 `.agents/skills/xiaotao`），不执行项目提供的脚本。自定义安装可由用户配置 `XIAOTAO_CORE_ROOT` 和 `XIAOTAO_PYTHON`。Python 使用独立参数和 stdin，避免 shell 重定向及平台删除命令。

插件核对每日与关联工作文件的当前字节后登记回执；重复或无变化的成功保存可在本轮重新核验，不靠重写时间戳冒充新事实。后续文件变化会使回执失效。保存失败自动登记 failed 并返回非零退出码。

无新事实或用户要求不保存时仍用 `--ack` 登记 skipped；普通跳过不能消除之前的未保存状态。Hook 不自动总结聊天，也不证明模型已涵盖所有事实。
